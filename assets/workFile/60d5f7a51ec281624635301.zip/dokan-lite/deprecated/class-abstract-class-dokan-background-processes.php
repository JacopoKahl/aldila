<?php

use WeDevs\Dokan\Abstracts\DokanBackgroundProcesses;

/**
 * Abstract Dokan_Background_Processes class
 */
abstract class Abstract_Dokan_Background_Processes extends DokanBackgroundProcesses {}
