/**
 * Backward compatibility script.
 * Attached to `google-maps` handle
 */
